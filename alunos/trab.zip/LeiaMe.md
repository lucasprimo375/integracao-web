O Trabalho foi feito supondo que os documentos se chamam alunos, campi.
Não foi feita a rota de incluir nem de alterar campus.
A rota de deletar campus ficou icompleta.